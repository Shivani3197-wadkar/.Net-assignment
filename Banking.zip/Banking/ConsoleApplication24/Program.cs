﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication24
{
    class Program
    {
        static void Main(string[] args)
        {
            Banking b = new Banking();
            b.NetBalance = 2000;
            b.OverBalance(b.NetBalance);
            b.UnderBalace();
            Console.ReadLine();


        }
    }
}
